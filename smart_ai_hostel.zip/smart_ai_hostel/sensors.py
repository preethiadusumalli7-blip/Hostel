"""sensors.py
Simulated sensors, devices, energy maths and Demo Mode.
All room data lives in one dictionary ("state") stored in st.session_state.

Time is SIMULATED: sim_now() = real clock + clock_offset. The "fast-forward"
buttons (and Demo Mode) just increase clock_offset, so timeouts can be shown
in seconds instead of waiting minutes.
"""
import random
from datetime import datetime, timedelta

import database as db

WATTS = {"light": 10, "fan": 60, "ac": 1000, "socket": 100}
LABELS = {"light": "Light", "fan": "Fan", "ac": "AC", "socket": "Power Socket"}
STEP = 10  # seconds simulated per step when fast-forwarding


def default_state():
    now = datetime.now()
    return {
        "clock_offset": 0.0,
        "last_tick": now,
        "devices": {d: False for d in WATTS},
        "mode": "Auto",                 # "Auto" or "Manual"
        "motion": False,                # PIR sensor
        "door_open": False,             # door sensor
        "people": 0,                    # occupancy sensor
        "last_motion": None,
        "entered_at": None,
        "empty_since": now,
        "door_opened_since_motion": False,
        "light_timeout": 20,            # sim seconds without motion -> lights OFF
        "empty_timeout": 60,            # sim seconds without motion (after door opened) -> Empty
        "inactivity_limit": 600,        # sim seconds without movement -> "Check Room"
        "night_override": False,
        "energy_wh": 0.0,
        "usage_sec": {d: 0.0 for d in WATTS},
        "occupied_sec": 0.0,
        "failed_times": [],
        "otp": None,
        "otp_expiry": None,
        "alert_keys": set(),
        "demo": False,
    }


def sim_now(state):
    return datetime.now() + timedelta(seconds=state["clock_offset"])


def current_power(state):
    """Watts being drawn right now."""
    return sum(WATTS[d] for d, on in state["devices"].items() if on)


def log_event(state, category, description, severity="Info", **kwargs):
    db.add_log(category, description, severity, timestamp=sim_now(state), **kwargs)


# ---------- Occupancy helpers ----------
def idle_seconds(state):
    if state["last_motion"] is None:
        return float("inf")
    return (sim_now(state) - state["last_motion"]).total_seconds()


def occupancy_status(state):
    if state["people"] == 0:
        return "Empty"
    if state["motion"] or idle_seconds(state) < state["empty_timeout"]:
        return "Occupied"
    return "Occupied (Inactive)"


def time_in_room(state):
    if state["entered_at"] is None:
        return "-"
    secs = int((sim_now(state) - state["entered_at"]).total_seconds())
    return f"{secs // 3600}h {secs % 3600 // 60}m {secs % 60}s"


def last_movement(state):
    return state["last_motion"].strftime("%H:%M:%S") if state["last_motion"] else "No movement yet"


# ---------- Sensor actions ----------
def register_motion(state, log=True):
    """PIR detects motion -> room Occupied; in Auto mode the light turns ON."""
    now = sim_now(state)
    if state["people"] == 0:
        state["people"] = 1
        state["entered_at"] = now
    state["motion"] = True
    state["last_motion"] = now
    state["door_opened_since_motion"] = False
    if log:
        log_event(state, "Motion", "PIR motion detected")
    if state["mode"] == "Auto":
        set_device(state, "light", True, "auto: motion detected")


def stop_motion(state):
    if not state["motion"]:
        return
    state["motion"] = False
    log_event(state, "Motion", "PIR: motion stopped")


def set_door(state, open_):
    if state["door_open"] == open_:
        return
    state["door_open"] = open_
    if open_:
        state["door_opened_since_motion"] = True
    log_event(state, "Door Access", f"Door sensor: door {'opened' if open_ else 'closed'}")


def set_people(state, n):
    n = max(0, int(n))
    now = sim_now(state)
    if n > 0 and state["people"] == 0:
        state["entered_at"], state["last_motion"] = now, now
        state["door_opened_since_motion"] = False
    if n == 0 and state["people"] > 0:
        state["entered_at"], state["empty_since"], state["motion"] = None, now, False
    if n != state["people"]:
        log_event(state, "Motion", f"Occupancy sensor: {n} person(s) detected")
    state["people"] = n


def set_device(state, name, on, source="manual"):
    if state["devices"][name] == on:
        return
    state["devices"][name] = on
    log_event(state, "Device", f"{LABELS[name]} turned {'ON' if on else 'OFF'} ({source})")


# ---------- Time passing ----------
def tick(state):
    """Update energy use and run the automatic rules. Called on every page refresh."""
    now = sim_now(state)
    dt = max(0.0, (now - state["last_tick"]).total_seconds())
    state["last_tick"] = now

    # Energy = watts x hours, for every device that was ON
    for name, on in state["devices"].items():
        if on:
            state["usage_sec"][name] += dt
            state["energy_wh"] += WATTS[name] * dt / 3600
    if state["people"] > 0:
        state["occupied_sec"] += dt

    if state["motion"]:                 # continuous movement keeps the timer fresh
        state["last_motion"] = now
    idle = idle_seconds(state)

    # Auto mode: no motion for a while -> lights OFF
    if state["mode"] == "Auto" and state["devices"]["light"] and not state["motion"] and idle >= state["light_timeout"]:
        set_device(state, "light", False, "auto: no-motion timeout")

    # Someone left (door was opened) and no motion for a while -> room Empty
    if state["people"] > 0 and not state["motion"] and state["door_opened_since_motion"] and idle >= state["empty_timeout"]:
        set_people(state, 0)


def fast_forward(state, seconds):
    """Jump the simulated clock forward in small steps so timeouts fire correctly."""
    for _ in range(max(1, int(seconds // STEP))):
        state["clock_offset"] += STEP
        tick(state)


# ---------- Demo Mode ----------
def demo_step(state):
    """One round of random sensor activity (called every few seconds in Demo Mode)."""
    import security  # imported here to avoid a circular import

    if random.random() < 0.35:
        stop_motion(state) if state["motion"] else register_motion(state)
    if random.random() < 0.15:
        set_people(state, random.choice([0, 1, 1, 2, 3]))
    if random.random() < 0.25:
        options = ["fan", "ac", "socket"] + (["light"] if state["mode"] == "Manual" else [])
        name = random.choice(options)
        set_device(state, name, not state["devices"][name], "demo")
    roll = random.random()
    if roll < 0.20:
        security.attempt_access(state, random.choice(list(db.REGISTERED_USERS)), "Demo RFID")
    elif roll < 0.30:
        security.attempt_access(state, f"HST{random.randint(9000, 9999)}", "Demo RFID")
    elif roll < 0.34:  # burst of failures -> Security Alert
        for _ in range(3):
            security.attempt_access(state, f"HST{random.randint(9000, 9999)}", "Demo RFID")
    if random.random() < 0.05:
        state["night_override"] = not state["night_override"]
    fast_forward(state, 30)
