"""security.py
Simulated room access: RFID/ID card, fingerprint button and guest OTP.
"""
import random
import secrets
from datetime import timedelta

import database as db
import sensors

OTP_VALID_MINUTES = 5


def _let_in(state):
    """A person walks in: door opens and the PIR sees movement."""
    sensors.set_door(state, True)
    sensors.register_motion(state, log=False)
    state["failed_times"].clear()


def _deny(state):
    state["failed_times"].append(sensors.sim_now(state))


def attempt_access(state, id_text, method="RFID/ID"):
    """Check an ID. Returns (granted: bool, message: str) and logs the attempt."""
    user_id = (id_text or "").strip().upper()
    if not user_id:
        return False, "Please enter an ID first."
    if user_id in db.REGISTERED_USERS:
        name = db.REGISTERED_USERS[user_id]
        sensors.log_event(state, "Door Access", f"{method} entry: {user_id} ({name})", user_id=user_id, result="Granted")
        _let_in(state)
        return True, f"Access Granted - welcome {name}!"
    sensors.log_event(state, "Door Access", f"{method} denied: unregistered ID {user_id}", "Warning", user_id=user_id, result="Denied")
    _deny(state)
    return False, "Access Denied - ID not registered."


def simulate_fingerprint(state):
    """Fake fingerprint scan: ~80% of scans match a registered student."""
    if random.random() < 0.8:
        return attempt_access(state, random.choice(list(db.REGISTERED_USERS)), "Fingerprint")
    return attempt_access(state, "UNKNOWN-FP", "Fingerprint")


def generate_otp(state):
    """Create a 6-digit guest OTP valid for a few minutes."""
    code = f"{secrets.randbelow(10 ** 6):06d}"
    state["otp"] = code
    state["otp_expiry"] = sensors.sim_now(state) + timedelta(minutes=OTP_VALID_MINUTES)
    sensors.log_event(state, "Guest Entry", "Guest OTP generated", user_id="GUEST")
    return code


def verify_otp(state, code):
    """Check the OTP typed in. Returns (granted, message). OTP works only once."""
    code = (code or "").strip()
    if not code:
        return False, "Please enter the OTP first."
    if not state["otp"] or sensors.sim_now(state) > state["otp_expiry"]:
        state["otp"] = None
        sensors.log_event(state, "Guest Entry", "OTP attempt with no valid OTP (expired)", "Warning", user_id="GUEST", result="Denied")
        _deny(state)
        return False, "Access Denied - OTP expired or not generated."
    if code == state["otp"]:
        state["otp"] = None
        sensors.log_event(state, "Guest Entry", "Guest OTP verified - visitor entered", user_id="GUEST", result="Granted")
        _let_in(state)
        return True, "Access Granted - guest OTP verified."
    sensors.log_event(state, "Guest Entry", "Wrong guest OTP entered", "Warning", user_id="GUEST", result="Denied")
    _deny(state)
    return False, "Access Denied - wrong OTP."
