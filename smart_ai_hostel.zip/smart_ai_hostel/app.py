"""app.py - Smart AI Hostel Room dashboard.
Run with:  streamlit run app.py

Flow: Secure Room Access -> Smart Devices -> Occupancy Detection ->
      Energy Monitoring -> AI-Based Alerts -> Admin Analytics
"""
import time

import pandas as pd
import streamlit as st

import ai_detection
import analytics
import database as db
import security
import sensors

st.set_page_config(page_title="Smart AI Hostel Room", page_icon="🏠", layout="wide")

# ---------- Dark smart-home styling ----------
st.markdown("""
<style>
[data-testid="stMetric"] {background:#1a2033; border:1px solid #2d3a5c; border-radius:14px; padding:14px 16px;}
[data-testid="stMetricValue"] {font-size:1.5rem;}
[data-testid="stSidebar"] {background:#111726;}
h1, h2, h3 {letter-spacing:0.3px;}
</style>
""", unsafe_allow_html=True)

db.init_db()
if "room" not in st.session_state:
    st.session_state.room = sensors.default_state()


def R():
    return st.session_state.room


# ---------- Button / toggle callbacks (they run BEFORE the page redraws) ----------
def cb_device(name):
    sensors.set_device(R(), name, st.session_state[f"tg_{name}"], "manual")


def cb_mode():
    room = R()
    room["mode"] = st.session_state.mode_radio
    sensors.log_event(room, "Device", f"Mode switched to {room['mode']}")
    if room["mode"] == "Auto" and room["motion"]:
        sensors.set_device(room, "light", True, "auto: motion detected")


def cb_motion():
    room, on = R(), st.session_state.tg_motion
    if on and not room["motion"]:
        sensors.register_motion(room)
    elif not on:
        sensors.stop_motion(room)


def cb_door():
    sensors.set_door(R(), st.session_state.tg_door)


def cb_people():
    sensors.set_people(R(), st.session_state.num_people)


def cb_leave():
    room = R()
    sensors.set_door(room, True)
    sensors.stop_motion(room)
    sensors.set_people(room, 0)


def cb_night():
    R()["night_override"] = st.session_state.tg_night


def cb_forward(seconds):
    sensors.fast_forward(R(), seconds)


def cb_demo():
    R()["demo"] = st.session_state.demo_toggle


def cb_scan():
    st.session_state.access_result = security.attempt_access(R(), st.session_state.id_input, "RFID/ID")
    st.session_state.id_input = ""


def cb_fingerprint():
    st.session_state.access_result = security.simulate_fingerprint(R())


def cb_gen_otp():
    security.generate_otp(R())


def cb_verify_otp():
    st.session_state.access_result = security.verify_otp(R(), st.session_state.otp_input)
    st.session_state.otp_input = ""


def cb_clear_logs():
    db.clear_logs()


def cb_reset_logs():
    db.reset_demo_data()


# ---------- Small display helpers ----------
def onoff(on):
    return "🟢 ON" if on else "⚫ OFF"


def show_alerts(alerts):
    """Show active alerts with Streamlit alert boxes."""
    if not alerts:
        st.success("✅ All systems normal - no active alerts.")
    for a in alerts:
        text = f"**{a['type']}** - {a['message']}"
        (st.error if a["severity"] == "Critical" else st.warning)(("🚨 " if a["severity"] == "Critical" else "⚠️ ") + text)


SEVERITY_ICON = {"Critical": "🔴 Critical", "Warning": "🟠 Warning", "Info": "🔵 Info"}
RENAME = {"timestamp": "Date & Time", "room": "Room", "category": "Type", "user_id": "ID",
          "result": "Result", "description": "Description", "severity": "Severity"}


def pretty(df):
    """Make a log DataFrame look nice for display."""
    out = df.copy()
    out["timestamp"] = out["timestamp"].dt.strftime("%d %b %Y %H:%M:%S")
    out["severity"] = out["severity"].map(lambda s: SEVERITY_ICON.get(s, s))
    return out.rename(columns=RENAME)


# ---------- Pages ----------
def page_home(room, alerts, logs):
    st.title("🏠 Smart AI Hostel Room")
    st.caption("Secure access → smart devices → occupancy → energy → AI alerts → analytics")
    secure = not any(a["type"] == "Security Alert" for a in alerts)

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("🚪 Room Number", db.ROOM_NUMBER)
    c2.metric("👤 Occupancy", sensors.occupancy_status(room), f"{room['people']} person(s)", delta_color="off")
    c3.metric("Door", "🔓 Open" if room["door_open"] else "🔒 Closed")
    c4.metric("🛡️ Security", "🔒 Secure" if secure else "🚨 ALERT")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("💡 Lights", onoff(room["devices"]["light"]))
    c2.metric("🌀 Fan", onoff(room["devices"]["fan"]))
    c3.metric("❄️ AC", onoff(room["devices"]["ac"]))
    c4.metric("⚡ Energy Usage", f"{room['energy_wh'] / 1000:.3f} kWh", f"{sensors.current_power(room)} W now", delta_color="off")

    st.progress(min(sensors.current_power(room) / sum(sensors.WATTS.values()), 1.0),
                text=f"Live power draw: {sensors.current_power(room)} W of {sum(sensors.WATTS.values())} W max")

    st.subheader("🤖 AI Alerts (live)")
    show_alerts(alerts)

    st.subheader("🔔 Recent Alerts")
    recent = logs[logs["category"].isin(db.ALERT_CATEGORIES)].head(5)
    if recent.empty:
        st.info("No alerts logged yet.")
    else:
        st.dataframe(pretty(recent)[["Type", "Date & Time", "Room", "Description", "Severity"]], hide_index=True)


def page_security(room, alerts, logs):
    st.title("🔐 Room Security")
    result = st.session_state.get("access_result")
    if result:
        (st.success if result[0] else st.error)(("✅ " if result[0] else "⛔ ") + result[1])

    left, right = st.columns(2)
    with left:
        st.subheader("RFID / ID Access")
        st.text_input("Enter RFID / Student ID", key="id_input", placeholder="e.g. HST1001")
        st.button("🔑 Scan ID", on_click=cb_scan)
        st.button("🖐️ Simulate Fingerprint Scan", on_click=cb_fingerprint)
        with st.expander("Demo IDs (registered)"):
            st.table(pd.DataFrame({"ID": list(db.REGISTERED_USERS), "Name": list(db.REGISTERED_USERS.values())}))
    with right:
        st.subheader("Guest OTP")
        st.button("🎟️ Generate Guest OTP", on_click=cb_gen_otp)
        if room["otp"] and room["otp_expiry"] > sensors.sim_now(room):
            st.info(f"Guest OTP: **{room['otp']}**  (valid until {room['otp_expiry']:%H:%M:%S})")
        st.text_input("Enter OTP", key="otp_input", max_chars=6, placeholder="6-digit code")
        st.button("✔️ Verify OTP", on_click=cb_verify_otp)

    failed = ai_detection.recent_failed(room)
    if failed >= ai_detection.FAILED_LIMIT:
        st.error(f"🚨 SECURITY ALERT: {failed} failed attempts in the last 10 minutes!")
    else:
        st.success(f"Security normal - {failed} recent failed attempt(s).")

    st.subheader("⛔ Unauthorized Access Attempts")
    denied = logs[logs["result"] == "Denied"].head(10)
    if denied.empty:
        st.info("No unauthorized attempts recorded.")
    else:
        st.dataframe(pretty(denied)[["Date & Time", "ID", "Type", "Description"]], hide_index=True)


def page_controls(room, alerts, logs):
    st.title("🎛️ Smart Controls")
    # Keep widgets in sync with the real state (auto rules may have changed it)
    for d in sensors.WATTS:
        st.session_state[f"tg_{d}"] = room["devices"][d]
    st.session_state.update(tg_motion=room["motion"], tg_door=room["door_open"], num_people=room["people"],
                            tg_night=room["night_override"], mode_radio=room["mode"])

    st.radio("Control mode", ["Auto", "Manual"], horizontal=True, key="mode_radio", on_change=cb_mode)
    st.caption("Auto: lights follow motion and switch OFF after a timeout. Manual: you control the light yourself.")

    st.subheader("Devices")
    cols = st.columns(4)
    icons = {"light": "💡", "fan": "🌀", "ac": "❄️", "socket": "🔌"}
    for col, d in zip(cols, sensors.WATTS):
        with col:
            st.toggle(f"{icons[d]} {sensors.LABELS[d]}", key=f"tg_{d}", on_change=cb_device, args=(d,),
                      disabled=(d == "light" and room["mode"] == "Auto"))
            st.caption(f"{sensors.WATTS[d]} W")

    st.subheader("Simulated Sensors")
    a, b, c = st.columns(3)
    a.toggle("🏃 PIR motion detected", key="tg_motion", on_change=cb_motion)
    b.toggle("🚪 Door open", key="tg_door", on_change=cb_door)
    c.number_input("👥 People in room", min_value=0, max_value=6, step=1, key="num_people", on_change=cb_people)

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Room status", sensors.occupancy_status(room))
    m2.metric("People detected", room["people"])
    m3.metric("Last movement", sensors.last_movement(room))
    m4.metric("Time in room", sensors.time_in_room(room))

    st.subheader("Time & Automation")
    b1, b2, b3, b4 = st.columns(4)
    b1.button("⏩ +1 min", on_click=cb_forward, args=(60,))
    b2.button("⏩ +5 min", on_click=cb_forward, args=(300,))
    b3.button("⏩ +30 min", on_click=cb_forward, args=(1800,))
    b4.button("🚶 Everyone leaves", on_click=cb_leave)
    st.toggle("🌙 Simulate night-time (unusual hours)", key="tg_night", on_change=cb_night)
    with st.expander("Timeout settings (simulated seconds)"):
        room["light_timeout"] = st.slider("Lights OFF after no motion", 5, 120, room["light_timeout"])
        room["empty_timeout"] = st.slider("Mark room Empty after no motion (once door opened)", 10, 300, room["empty_timeout"])
        room["inactivity_limit"] = st.slider("'Check Room' alert after no movement", 60, 1800, room["inactivity_limit"])

    st.subheader("⚡ Energy Usage (this session)")
    table = pd.DataFrame({
        "Device": [sensors.LABELS[d] for d in sensors.WATTS],
        "Power (W)": list(sensors.WATTS.values()),
        "Hours ON": [round(room["usage_sec"][d] / 3600, 3) for d in sensors.WATTS],
        "Energy (Wh)": [round(room["usage_sec"][d] * sensors.WATTS[d] / 3600, 2) for d in sensors.WATTS],
    })
    st.dataframe(table, hide_index=True)
    st.metric("Total energy", f"{room['energy_wh'] / 1000:.3f} kWh")


def page_analytics(room, alerts, logs):
    st.title("📊 Occupancy Analytics")
    hist = analytics.hourly_history()
    daily = analytics.daily_summary(hist, room)
    s = analytics.stats(daily, logs)

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total occupied hours", f"{s['occupied_hours']:.1f} h")
    c2.metric("Total energy consumed", f"{s['energy_kwh']:.2f} kWh")
    c3.metric("Access attempts", s["attempts"])
    c4.metric("Unauthorized attempts", s["unauthorized"])
    st.caption("History is realistic sample data for the past 7 days; 'Today (live)' comes from this session.")

    left, right = st.columns(2)
    left.plotly_chart(analytics.fig_hourly_occupancy(hist))
    right.plotly_chart(analytics.fig_daily_usage(daily))
    left.plotly_chart(analytics.fig_energy(daily))
    right.plotly_chart(analytics.fig_device_usage(daily))
    st.plotly_chart(analytics.fig_access(logs))


def page_logs(room, alerts, logs):
    st.title("🚨 Alerts & Logs")
    st.subheader("Live alerts")
    show_alerts(alerts)

    st.subheader("Alert panel")
    severity = st.multiselect("Filter by severity", ["Critical", "Warning", "Info"], default=["Critical", "Warning", "Info"])
    alert_df = logs[logs["category"].isin(db.ALERT_CATEGORIES) & logs["severity"].isin(severity)]
    if alert_df.empty:
        st.info("No alerts to show.")
    else:
        st.dataframe(pretty(alert_df)[["Type", "Date & Time", "Room", "Description", "Severity"]], hide_index=True)

    st.subheader("Logs")
    tabs = st.tabs(["All"] + list(db.LOG_GROUPS))
    with tabs[0]:
        st.dataframe(pretty(logs).drop(columns=["Room"]).head(200), hide_index=True)
    for tab, (name, cats) in zip(tabs[1:], db.LOG_GROUPS.items()):
        with tab:
            part = logs[logs["category"].isin(cats)]
            if part.empty:
                st.info(f"No {name.lower()} logs.")
            else:
                st.dataframe(pretty(part).drop(columns=["Room"]).head(200), hide_index=True)

    b1, b2, b3 = st.columns(3)
    b1.button("🗑️ Clear demo logs", on_click=cb_clear_logs)
    b2.button("♻️ Restore sample data", on_click=cb_reset_logs)
    b3.download_button("⬇️ Download logs (CSV)", logs.to_csv(index=False), "hostel_logs.csv", "text/csv")


PAGES = {
    "🏠 Home Dashboard": page_home,
    "🔐 Room Security": page_security,
    "🎛️ Smart Controls": page_controls,
    "📊 Occupancy Analytics": page_analytics,
    "🚨 Alerts & Logs": page_logs,
}

# ---------- Sidebar ----------
room = R()
with st.sidebar:
    st.header("🏠 Smart AI Hostel")
    page = st.radio("Navigate", list(PAGES), label_visibility="collapsed")
    st.divider()
    st.toggle("🎬 Demo Mode", value=room["demo"], key="demo_toggle", on_change=cb_demo,
              help="Randomly simulates motion, occupancy, access attempts, energy use and alerts.")
    if room["demo"]:
        st.caption("Demo running - refreshing every 3 s")
    st.caption(f"Room {db.ROOM_NUMBER} · simulated time {sensors.sim_now(room):%H:%M:%S}")

# ---------- Every refresh: advance time, run demo, run AI rules ----------
try:
    sensors.tick(room)
    if room["demo"]:
        sensors.demo_step(room)
    active_alerts = ai_detection.sync_alerts(room)
    all_logs = db.read_logs()
    PAGES[page](room, active_alerts, all_logs)
except Exception as exc:  # keep the demo alive even if something unexpected happens
    st.error(f"Something went wrong: {exc}")

if room["demo"]:
    time.sleep(3)
    st.rerun()
