"""ai_detection.py
Simple rule-based "AI" anomaly detection (if/else rules, no ML model).
"""
import database as db
import sensors

FAILED_LIMIT = 3          # failed attempts that trigger a Security Alert
FAILED_WINDOW = 600       # ... within this many (simulated) seconds
AC_EMPTY_LIMIT = 60       # AC ON while empty for this long -> Energy Warning
HIGH_POWER_W = 1100       # instant load above this -> High Energy Usage
HIGH_ENERGY_WH = 2000     # energy used this session above this -> High Energy Usage
NIGHT_END_HOUR = 5        # 00:00-05:00 counts as unusual hours


def recent_failed(state):
    """Number of failed access attempts inside the time window."""
    now = sensors.sim_now(state)
    state["failed_times"] = [t for t in state["failed_times"] if (now - t).total_seconds() <= FAILED_WINDOW]
    return len(state["failed_times"])


def detect(state):
    """Run every rule. Returns a list of currently active alerts."""
    now = sensors.sim_now(state)
    alerts = []

    n = recent_failed(state)
    if n >= FAILED_LIMIT:
        alerts.append(("Security Alert", "Critical", f"{n} failed access attempts in the last {FAILED_WINDOW // 60} minutes"))

    if state["motion"] and (state["night_override"] or now.hour < NIGHT_END_HOUR):
        alerts.append(("Unusual Activity", "Warning", f"Motion detected at unusual hour ({now:%H:%M})"))

    if state["devices"]["ac"] and state["people"] == 0 and (now - state["empty_since"]).total_seconds() >= AC_EMPTY_LIMIT:
        alerts.append(("Energy Warning", "Warning", "AC is ON while the room is empty"))

    if state["people"] > 0 and not state["motion"] and sensors.idle_seconds(state) >= state["inactivity_limit"]:
        mins = int(sensors.idle_seconds(state) // 60)
        alerts.append(("Check Room", "Warning", f"No movement for {mins} minutes although the room is occupied"))

    power = sensors.current_power(state)
    if power >= HIGH_POWER_W or state["energy_wh"] >= HIGH_ENERGY_WH:
        alerts.append(("High Energy Usage", "Warning", f"Power draw {power} W, session energy {state['energy_wh'] / 1000:.2f} kWh"))

    return [{"type": t, "severity": s, "message": m} for t, s, m in alerts]


def sync_alerts(state):
    """Run the rules and write each NEW alert to the log once. Returns active alerts."""
    active = detect(state)
    now = sensors.sim_now(state)
    for alert in active:
        if alert["type"] not in state["alert_keys"]:
            db.add_log(alert["type"], alert["message"], alert["severity"], timestamp=now)
    state["alert_keys"] = {a["type"] for a in active}
    return active
