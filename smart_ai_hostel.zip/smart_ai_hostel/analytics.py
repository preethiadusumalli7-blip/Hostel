"""analytics.py
Sample history + live data -> statistics and Plotly charts.
"""
import random
from datetime import datetime, timedelta

import pandas as pd
import plotly.graph_objects as go

from sensors import WATTS

TEMPLATE = "plotly_dark"
COLORS = {"light": "#ffd166", "fan": "#4cc9f0", "ac": "#ef476f", "socket": "#06d6a0"}


def _occupancy_probability(hour):
    """How likely a student is in the room at each hour of the day."""
    if hour < 8:
        return 0.95
    if hour < 10:
        return 0.5
    if hour < 17:
        return 0.2
    if hour < 19:
        return 0.6
    return 0.92


def hourly_history(days=7):
    """Realistic simulated hour-by-hour data for the past week."""
    rnd = random.Random(7)
    today = datetime.now().date()
    rows = []
    for d in range(days, 0, -1):
        day = today - timedelta(days=d)
        for h in range(24):
            occ = 1 if rnd.random() < _occupancy_probability(h) else 0
            night = h >= 18 or h < 6
            rows.append({
                "date": day, "hour": h, "occupied": occ,
                "people": occ * rnd.choice([1, 1, 1, 2]),
                "light_min": 60 if occ and night and rnd.random() < 0.85 else 0,
                "fan_min": 60 if occ and rnd.random() < 0.9 else 0,
                "ac_min": 60 if occ and (h >= 22 or h < 6) and rnd.random() < 0.5 else 0,
                "socket_min": 60 if rnd.random() < (0.7 if occ else 0.15) else 0,
            })
    return pd.DataFrame(rows)


def daily_summary(hist, state):
    """One row per day (hours occupied, hours + kWh per device). Today comes from the live session."""
    g = hist.groupby("date").sum(numeric_only=True).reset_index()
    daily = pd.DataFrame({"date": g["date"].astype(str), "occupied_h": g["occupied"]})
    for d in WATTS:
        daily[f"{d}_h"] = g[f"{d}_min"] / 60
    live = {"date": "Today (live)", "occupied_h": state["occupied_sec"] / 3600}
    for d in WATTS:
        live[f"{d}_h"] = state["usage_sec"][d] / 3600
    daily = pd.concat([daily, pd.DataFrame([live])], ignore_index=True)
    for d, w in WATTS.items():
        daily[f"{d}_kwh"] = daily[f"{d}_h"] * w / 1000
    daily["total_kwh"] = sum(daily[f"{d}_kwh"] for d in WATTS)
    return daily


def stats(daily, logs):
    attempts = logs[logs["result"].isin(["Granted", "Denied"])]
    return {
        "occupied_hours": daily["occupied_h"].sum(),
        "energy_kwh": daily["total_kwh"].sum(),
        "attempts": len(attempts),
        "unauthorized": int((attempts["result"] == "Denied").sum()),
    }


def _style(fig, title, ytitle=""):
    fig.update_layout(template=TEMPLATE, title=title, yaxis_title=ytitle, height=340,
                      margin=dict(l=10, r=10, t=50, b=10), paper_bgcolor="rgba(0,0,0,0)",
                      plot_bgcolor="rgba(0,0,0,0)", legend=dict(orientation="h", y=-0.2))
    return fig


def fig_hourly_occupancy(hist):
    avg = hist.groupby("hour")["occupied"].mean() * 100
    fig = go.Figure(go.Scatter(x=avg.index, y=avg.values, fill="tozeroy", line=dict(color="#00d4aa")))
    fig.update_xaxes(title="Hour of day", dtick=2)
    return _style(fig, "Occupancy throughout the day", "% of days occupied")


def fig_daily_usage(daily):
    fig = go.Figure(go.Bar(x=daily["date"], y=daily["occupied_h"], marker_color="#4cc9f0"))
    return _style(fig, "Daily room usage", "Hours occupied")


def fig_energy(daily):
    fig = go.Figure([go.Bar(name=w.title() if w != "ac" else "AC", x=daily["date"], y=daily[f"{w}_kwh"], marker_color=COLORS[w])
                     for w in WATTS])
    fig.update_layout(barmode="stack")
    return _style(fig, "Energy consumption", "kWh")


def fig_device_usage(daily):
    fig = go.Figure([go.Bar(name=w.title() if w != "ac" else "AC", x=daily["date"], y=daily[f"{w}_h"], marker_color=COLORS[w])
                     for w in ("light", "fan", "ac")])
    fig.update_layout(barmode="group")
    return _style(fig, "Light / Fan / AC usage", "Hours ON")


def fig_access(logs):
    attempts = logs[logs["result"].isin(["Granted", "Denied"])].copy()
    fig = go.Figure()
    if not attempts.empty:
        attempts["day"] = attempts["timestamp"].dt.strftime("%Y-%m-%d")
        counts = attempts.groupby(["day", "result"]).size().unstack(fill_value=0)
        for result, color in (("Granted", "#06d6a0"), ("Denied", "#ef476f")):
            if result in counts:
                fig.add_trace(go.Bar(name=result, x=counts.index, y=counts[result], marker_color=color))
    fig.update_layout(barmode="group")
    return _style(fig, "Number of access attempts", "Attempts")
