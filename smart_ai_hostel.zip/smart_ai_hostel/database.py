"""database.py
A tiny "database" built on one CSV file (data/hostel_logs.csv).
Every event (door access, motion, device switching, alerts...) is one row.
"""
import csv
import os
import random
from datetime import datetime, timedelta

import pandas as pd

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
LOG_FILE = os.path.join(DATA_DIR, "hostel_logs.csv")

ROOM_NUMBER = "B-204"
TIME_FORMAT = "%Y-%m-%d %H:%M:%S"
COLUMNS = ["timestamp", "room", "category", "user_id", "result", "description", "severity"]

# Registered students: RFID card / student ID -> name
REGISTERED_USERS = {
    "HST1001": "Aarav Sharma",
    "HST1002": "Riya Patel",
    "HST1003": "Kiran Reddy",
}

# Log categories that count as "alerts"
ALERT_CATEGORIES = ["Security Alert", "Unusual Activity", "Energy Warning", "Check Room", "High Energy Usage"]

# Tabs on the Alerts & Logs page -> categories shown in each tab
LOG_GROUPS = {
    "Door Access": ["Door Access"],
    "Guest Entry": ["Guest Entry"],
    "Motion": ["Motion"],
    "Device Switching": ["Device"],
    "Security Alerts": ["Security Alert", "Unusual Activity", "Check Room"],
    "Energy Warnings": ["Energy Warning", "High Energy Usage"],
}


def _seed_rows():
    """Create a week of realistic sample history (same every time: seed 42)."""
    rnd = random.Random(42)
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    ids = list(REGISTERED_USERS)
    rows = []

    def add(day, hh, mm, category, description, severity="Info", user="", result=""):
        ts = day + timedelta(hours=hh, minutes=mm, seconds=rnd.randint(0, 59))
        rows.append([ts.strftime(TIME_FORMAT), ROOM_NUMBER, category, user, result, description, severity])

    for d in range(7, 0, -1):
        day = today - timedelta(days=d)
        u1, u2 = rnd.choice(ids), rnd.choice(ids)
        add(day, 7, rnd.randint(0, 40), "Motion", "PIR motion detected - room active")
        add(day, 8, rnd.randint(30, 55), "Door Access", f"RFID/ID entry: {u1} ({REGISTERED_USERS[u1]})", user=u1, result="Granted")
        add(day, 18, rnd.randint(0, 50), "Door Access", f"RFID/ID entry: {u2} ({REGISTERED_USERS[u2]})", user=u2, result="Granted")
        add(day, 18, 55, "Device", "Light turned ON (auto: motion detected)")
        add(day, 22, rnd.randint(0, 40), "Device", "AC turned ON (manual)")
        if rnd.random() < 0.6:  # a stranger tries a card now and then
            bad = f"HST{rnd.randint(9000, 9999)}"
            add(day, rnd.randint(9, 21), rnd.randint(0, 59), "Door Access",
                f"RFID/ID denied: unregistered ID {bad}", "Warning", bad, "Denied")
        if d in (2, 5):
            add(day, 16, 20, "Guest Entry", "Guest OTP verified - visitor entered", "Info", "GUEST", "Granted")
        if d == 3:  # a security incident for the demo
            for m in (10, 12, 14):
                add(day, 2, m, "Door Access", "RFID/ID denied: unregistered ID HST9999", "Warning", "HST9999", "Denied")
            add(day, 2, 15, "Security Alert", "3 failed access attempts in 10 minutes", "Critical")
            add(day, 2, 16, "Unusual Activity", "Motion detected at unusual hour (02:16)", "Warning")
        if d == 4:
            add(day, 14, 30, "Energy Warning", "AC is ON while the room is empty", "Warning")
    return rows


def _write_rows(rows):
    with open(LOG_FILE, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(COLUMNS)
        writer.writerows(rows)


def init_db():
    """Create the data folder and CSV (with sample data) if they don't exist."""
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        if not os.path.exists(LOG_FILE) or os.path.getsize(LOG_FILE) == 0:
            _write_rows(_seed_rows())
    except OSError as exc:
        print(f"Could not create log file: {exc}")


def add_log(category, description, severity="Info", user_id="", result="", timestamp=None, room=ROOM_NUMBER):
    """Append one event to the CSV. Returns True on success."""
    ts = (timestamp or datetime.now()).strftime(TIME_FORMAT)
    try:
        with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([ts, room, category, user_id, result, description, severity])
        return True
    except OSError as exc:
        print(f"Could not write log: {exc}")
        return False


def read_logs():
    """Return all logs as a DataFrame, newest first."""
    try:
        df = pd.read_csv(LOG_FILE, keep_default_na=False)
    except (FileNotFoundError, pd.errors.EmptyDataError):
        df = pd.DataFrame(columns=COLUMNS)
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    return df.dropna(subset=["timestamp"]).sort_values("timestamp", ascending=False).reset_index(drop=True)


def clear_logs():
    """Delete every log row (keeps the header)."""
    try:
        _write_rows([])
    except OSError as exc:
        print(f"Could not clear logs: {exc}")


def reset_demo_data():
    """Replace the logs with the sample history again."""
    try:
        _write_rows(_seed_rows())
    except OSError as exc:
        print(f"Could not reset logs: {exc}")
